describe("critical path", () => {
  beforeEach(() => {
    cy.viewport("iphone-7");
  });
 it('visits site', () => {

        cy.visit('https://github.com/webdriverio/nativedemo-app/releases')
    });

/// Login with Email and password

 it("Swipe horizontal", () => {
  cy.swipescreen()
  cy.swipeLeft()
  cy.swipeLeft()
  cy.swipeLeft()  
 });
});
