// tests.spec.js
describe('mobile-tests', () => {
  beforeEach(() => {
    cy.viewport('iphone-7')
  })
  
})