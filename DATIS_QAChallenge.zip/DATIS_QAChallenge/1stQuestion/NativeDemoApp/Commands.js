
const storage = new Storage;

Cypress.Commands.add('swipescreen', () => {
  cy.visit('/', {
    onBeforeLoad () {
      storage.set('i_did_swipe', false)
    }
  })
})

Cypress.Commands.add('swipeLeft', () => {
  cy.get('.swiper-slide-active')
    .trigger('mousedown', {position: "right"})
    .trigger('mousemove', {clientX: 100, clientY: 275})
    .trigger('mouseup', {force: true})
})