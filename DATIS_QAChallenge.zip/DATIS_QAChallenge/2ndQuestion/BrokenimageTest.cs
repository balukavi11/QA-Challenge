package com.Multi;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.But;
 
import java.util.List;
 
import cucumber.api.PendingException;
import cucumber.api.java.it.Data;
import cucumber.runtime.ScenarioImpl;
import gherkin.formatter.model.Scenario;
import gherkin.formatter.model.ScenarioOutline;
import cucumber.api.DataTable;
 
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
 
import cucumber.api.cli.Main;
 
public class Step {
     
    static public String sb;
    static public String sa;
    static WebDriver driver = null;
     
    @Before("@Regression")
    public void beforeScenario(){
        System.out.println("New scenario begins");
    }   
     
    @After("@Smoke,@Regression")
    public void afterScenario(){
        System.out.println("Scenario ends");
     
     
    }
     
@MyAnnotation
public static void mytestresult()
{
        System.out.println("My scenario gets executed for broken images");
}
    @Given("^I am on Herokuapp page$")
    public void i_am_on_Herokuapp_page(){
       
        System.setProperty("webdriver.chrome.driver", 
"Executables\\chromedriver.exe");
        driver = new ChromeDriver();
        driver.navigate().to(site);              
    }
        
    @Given("^I click on Your Images$")
    public void i_click_on_Your_Images(){
        driver.findElement(By.xpath("//*[@id='user
-links']/li[3]/broken_images")).click();
        
        for(WebElement o:olist)
        {
            if(o.getText().equals("Image 1"))
            {
                o.click();
                break;
            }
        }              
    }   
 
    @When("^uploaded new image$")
    public void uploaded_new_image() throws InterruptedException{
        WebElement s1 = driver.findElement(By.xpath("//*[@class='avatar-upload
-container clearfix']/Img"));
        sb=s1.getAttribute("src");
        System.out.println(s1.getAttribute("src"));
        driver.findElement(By.id("upload-images
")).sendKeys("D://cucumberFinal//multiple//Files//images.jpg");
        Thread.sleep(10000);
        String wh = driver.getWindowHandle();
        driver.switchTo().window(wh);
         
        Actions actions = new Actions(driver);
         WebElement element = driver.findElement(By.xpath("//div[@class='facebox
-content']/form/div[3]/button"));
         Thread.sleep(10000);
         actions.moveToElement(element);
         
         actions.click();
         
         actions.build().perform();
   
         Thread.sleep(3000);        
    }
 
    @Then("^I should be seeing new image$")
    public void i_should_be_seeing_new_image(){
        WebElement s1 = driver.findElement(By.xpath("//*[@class='image-upload
-container']/Img"));
        sb=s1.getAttribute("src");
        System.out.println(s1.getAttribute("src"));
        if(!(sb.equals(sa)))
        {
        Assert.assertTrue("Image displayed successfully", true);
        }
        
    }     
    
}