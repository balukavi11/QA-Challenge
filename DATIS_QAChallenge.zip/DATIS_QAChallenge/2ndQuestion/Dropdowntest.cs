﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ToolsQA.Selenium_Basics
{
    class DropDownAndSelectOperations
    {
        [Test]
        public void Test()
        {

            // Create a new instance of the Firefox driver
            IWebDriver driver = new FirefoxDriver();

            driver.Manage().Timeouts().ImplicitlyWait(TimeSpan.FromSeconds(10));

            // Launch the URL
            driver.Url = "https://the-internet.herokuapp.com/dropdown";

            SelectElement oSelection = new SelectElement(driver.FindElement(By.Id("Dropdown List")));

           
            oSelection.SelectByText("Option 1");

           Thread.Sleep(2000);

           oSelection.SelectByIndex(2);
            Thread.Sleep(2000);

            IList<IWebElement> oSize = oSelection.Options;

            int iListSize = oSize.Count;
            
            for (int i = 0; i < iListSize; i++)
            {
                
                String sValue = oSelection.Options.ElementAt(i).Text;
               
                Console.WriteLine("Value of the Select item is : " + sValue);

               
                if (sValue.Equals("Option 2"))
                {
                    oSelection.SelectByIndex(i);
                    break;
                }

            }
            
            driver.Close();
        }
    }
}